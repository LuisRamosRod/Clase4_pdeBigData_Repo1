# Datasets
Los archivos csv han sido elaborados previamente usando la [Encuesta Nacional de Hogares](https://webinei.inei.gob.pe/anda_inei/index.php/catalog/543) del a�o 2016.
# M�dulos usados
* M�dulo 3: Educaci�n
* M�dulo 34: Sumaria


